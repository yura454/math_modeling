import lab_6_ex2

