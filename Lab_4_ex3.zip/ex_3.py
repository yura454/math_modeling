from constant import g
def energe(m, h, v):
  U=m*g*h
  K=(m*v**2)/2
  E=U+K
  print(E)
energe(10,10,5)


