import ex_3
