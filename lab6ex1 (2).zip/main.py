import lab_6_ex1

