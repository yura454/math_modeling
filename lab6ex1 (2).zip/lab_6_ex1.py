import matplotlib.pyplot as plt 
import numpy as np 

plt.plot([1,1,5,5,1],[1,5,5,1,1], marker='o')
plt.show()