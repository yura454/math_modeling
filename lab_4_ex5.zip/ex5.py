from math import pi
def f(key=0, h=0, l=0, R=0, a=0, b=0):
  if key==0:
    S=(h*l)/2
  if key==1:
    S=pi*R**2
  if key==2:
    S=a*b
  print(S)
f(key=0,h=5, l=3)
f(key=1, R=5)
f(key=2, a=7, b=12)
