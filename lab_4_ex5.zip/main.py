import ex5
